/**
 * Controller for the user functionality
 * 
 * @returns this
 */

function userController() {

    var User = require('../models/user'); // get the user model

    /**
     * This Function creates a new user 
     * 
     * @param {any} req
     * @param {any} res
     * @param {any} next
     */
    this.createUser = function(req, res, next) {
        /*
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        */
        console.log("creating users");

        // get coordinates [ <longitude> , <latitude> ]
        var coords = [];
        coords[0] = req.params.longitude || 0;
        coords[1] = req.params.latitude || 0;

        User.create({
            username: req.params.username,
            password: req.params.password,
            email: req.params.email,
            category: req.params.category,
            about: req.params.about || '',
            coordinates: coords,
            city: req.params.city,
            media: {
                youtube_url: req.params.youtube || '',
                soundcloud_url: req.params.soundcloud || '',
                website_url: req.params.website || ''
            },
            messages: null,
            likes: null,
            isArtist: req.params.isArtist,
            user_reviews: null
        }, function(err, result) {
            if (err) {
                console.log(err);
                return res.send({
                    'error': err
                });
            } else {
                return res.send({
                    'result': result,
                    'status': 'successfully saved'
                });
            }
        });
    };

    this.findUserByToken = function(req, res, next) {
        /* res.header("Access-Control-Allow-Origin", "*");
         res.header("Access-Control-Allow-Headers", "X-Requested-With");
         */
        console.log('req.params.email: ', req.params.token)

        User.findOne({
            email: req.params.token
        }, function(err, user) {
            if (err || user == null) {
                res.writeHead(403, {
                    'Content-Type': 'application/json; charset=utf-8'
                });
                res.end(JSON.stringify({
                    error: "Invalid User"
                }));
            } else {
                res.writeHead(200, {
                    'Content-Type': 'application/json; charset=utf-8'
                });
                console.log('user: ', user)
                res.end(JSON.stringify(user));
            }
        })

        return next();
    };

    /**
     *  This function gets all users from the db
     * 
     * @param {any} req
     * @param {any} res
     * @param {any} next
     */
    this.getUsers = function(req, res, next) {
        /*
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
*/
        User.find({}, function(err, result) {
            if (err) {
                console.log(err);
                return res.send({
                    'error': err
                });
            } else {
                return res.send({
                    'user Details': result
                });
            }
        });
    };

    /**
     *  This function gets all users with given param from the db
     * 
     * @param {any} req
     * @param {any} res
     * @param {any} next
     */
    this.getUsersAround = function(req, res, next) {
        var limit = req.params.limit || 10;
        // get the max distance or set it to 8 kilometers
        var dist = parseInt(req.params.distance) || 5; // maxdistance in radius
        // console.log("maxDistance * 1000: ", maxDistance * 1000)
        var maxDistInMeters = dist * 1000; // convert km to meters
        var category = req.params.category || 8;

        // get coordinates [ <longitude> , <latitude> ]
        var coords = [parseFloat(req.params.longitude), parseFloat(req.params.latitude)]

        var point = {
            type: "Point",
            coordinates: coords
        };
        // find a location
        User.geoNear(point, {
                maxDistance: parseInt(maxDistInMeters),
                distanceField: "dist.calculated",
                query: {
                    category: category
                },
                includeLocs: "dist.location",
                num: 5, // limit the results
                spherical: true
            }
            /*
            .find({
                coordinates: {
                    $geoNear: {
                        near: { type: "Point", coordinates: [ -73.99279 , 40.719296 ] },
                        distanceField: "dist.calculated",
                        maxDistance: 2,
                        query: { category: category },
                        includeLocs: "dist.location",
                        num: 5,
                        spherical: true
                    }

                */

            // category: category
            ,
            function(err, users, stats) {
                if (err) {
                    return res.json(500, err);
                }
                console.log("users: ", users)
                console.log("stats: ", stats)
                res.json(200, users);
            });
    };

    // TODO: adapt function for needs

    // Update Details of User
    this.updateUserPosition = function(req, res, next) {
        var coords = [req.params.longitude, req.params.latitude]; // the new user location coordinates
        console.log("FUNCTION updateUserPosition CALLLLLLED!")

        // find user with given email adress....
        User.findOne({
            email: req.params.email
        }, function(error, user) {
            if (error) {
                console.log("couldn't find the user: ", error)
                return res.send({
                    'error': error
                });
            } else {
                user.coordinates = coords;
                var promise = user.save();
                promise.then(function(data) {
                    console.log("user saved, data: ", data)
                    res.send(user);
                    res.end(JSON.stringify('user saved'));
                });
            }
        });

    };

    /**
     * This function updates the user
     * 
     * @param {any} req
     * @param {any} res
     * @param {any} next
     * @returns updated user
     */
    this.updateUser = function(req, res, next) {

        return User.findById(req.params.id, function(err, user) {

            user.username = req.params.username,
                user.password = req.params.password,
                user.email = req.params.email,
                user.category = req.params.category,
                user.about = req.params.about || '',
                user.city = req.params.city,
                user.media.youtube_url = req.params.youtube || '',
                user.media.soundcloud_url = req.params.soundcloud || '',
                user.media.website_url = req.params.website || '',
                user.messages = null,
                user.likes = null,
                user.isArtist = req.params.isArtist,
                user.user_reviews = null

            return user.save(function(err) {
                if (!err) {
                    console.log("updated");
                } else {
                    console.log(err);
                }
                return res.send(user);
            });
        });
    };

    this.deleteUser = function(req, res, next) {
        return User.findById(req.params.id, function(err, user) {
            return user.remove(function(err) {
                if (!err) {
                    console.log("user removed");
                    return res.send('');
                } else {
                    console.log(err);
                }
            });
        });
    };

    return this;

};



module.exports = new userController();