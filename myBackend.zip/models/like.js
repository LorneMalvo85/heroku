module.exports = (function likeSchema() {
    // import the necessary modules
    var mongoose = require('../db').mongoose;
    var user = require('./user');
 //   var User = mongoose.model('User');

    var Schema = mongoose.Schema;


    var LikeSchema = new Schema({
        user_liked: {
            type: Schema.Types.ObjectId,
            created_by: 'User'
        }
    }, {
        timestamps: {
            createdAt: 'created_at',
        }
    });

    // register the mongoose Model
    // model creation
    var LikeModel = mongoose.model('Like', LikeSchema);


    return LikeModel;
})();