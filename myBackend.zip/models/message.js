module.exports = (function messageSchema() {
    // import the necessary modules
    var mongoose = require('../db').mongoose;
    var Schema = mongoose.Schema;

    // model creation
    var MessageSchema = new Schema({
        from: String,
        to: String,
        title: String,
        text: String,
        unread: Boolean,
    },{
        timestamps: {
             createdAt: 'created_at',
             updatedAt: 'updated_at'
         },
    });

    var MessageModel = mongoose.model('Message', MessageSchema);

    return MessageModel;
})();