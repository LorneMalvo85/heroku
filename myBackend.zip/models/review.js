module.exports = (function reviewSchema() {
    // import the necessary modules
	var mongoose = require('../db').mongoose;
    var user = require('./user');
    //var User = mongoose.model('User');

    var Schema = mongoose.Schema;

    var ReviewSchema = new Schema({
        created_by: {
            type: Schema.Types.ObjectId,
            created_by: 'User'
        },
        title: String,
        text: String,
        ratings: Number
    }, {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at'
        }
    });

    // register the mongoose Model
    var ReviewModel = mongoose.model('Review', ReviewSchema);



    return ReviewModel;
})();