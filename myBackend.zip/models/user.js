// TODO Comment
module.exports = (function userSchema() {
    // import the necessary modules
    var mongoose = require('../db').mongoose;
    console.log("mongoose: ", mongoose)
    var like = require('./like');
    // var Like = mongoose.model('Like');
    var review = require('./review');
    // var Review = mongoose.model('Review');
    var message = require('./message');
    // var Message = mongoose.model('Message');

    var Schema = mongoose.Schema;


    var UserSchema = new Schema({
        username: String,
        password: String,
        email: String,
        category: String,
        about: String,
        coordinates: {
            type: [Number], // [ <longitude> , <latitude> ]
            index: '2dsphere' // create geospatial index
        },
        city: String,
        media: {
            youtube_url: String,
            soundcloud_url: String,
            website_url: String
        },
        messages: [{
            type: Schema.Types.ObjectId,
            created_by: 'Message'
        }],
        likes: [{
            type: Schema.Types.ObjectId,
            created_by: 'Like'
        }],
        isArtist: Boolean,
        user_reviews: [{
            type: Schema.Types.ObjectId,
            created_by: 'Review'
        }]
    }, {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at'
        }
    });

    var UserModel = mongoose.model('User', UserSchema);

    return UserModel;
})();